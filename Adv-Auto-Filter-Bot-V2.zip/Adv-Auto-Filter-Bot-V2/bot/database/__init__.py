from .database import Database

Database()
